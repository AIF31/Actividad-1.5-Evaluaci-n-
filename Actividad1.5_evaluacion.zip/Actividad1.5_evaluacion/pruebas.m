clc
clear all
t = linspace(0, 2*pi, 1000); % Intervalo de tiempo
x = 5*sin(t); % x(t) = sin(t)
y = 2*sin(x.^2); 

figure
plot(t, y)
title('Gráfica de la función 2*sin(x^2) parametrizada por el tiempo')
xlabel('Tiempo')
ylabel('2*sin(x^2)')
grid on